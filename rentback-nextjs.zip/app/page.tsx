"use client";
import RentBackLanding from "@/components/RentBackLanding";

export default function Page() {
  return <RentBackLanding />;
}
