export default {
  reactStrictMode: true,
};
